'''# mcp_server/educhain_wrapper.py

from educhain.engines.content_engine import ContentEngine
from educhain.core.config import LLMConfig
from test_python import MockLLM  # Use your working MockLLM


mock_llm = MockLLM()
mock_config = LLMConfig(custom_model=mock_llm)
engine = ContentEngine(llm_config=mock_config)

def get_lesson_plan(topic: str):
    return engine.generate_lesson_plan(topic)'''
from educhain.engines.content_engine import ContentEngine
from educhain.core.config import LLMConfig
from langchain_core.language_models import BaseLanguageModel
from langchain_core.messages import AIMessage
from langchain_core.outputs import ChatGeneration, ChatResult
import json

class MockLLM(BaseLanguageModel):
    def _call(self, prompt: str, stop=None, **kwargs) -> str:
        topic = "Python"
        return json.dumps({
            "title": f"Introduction to {topic}",
            "subject": "General Studies",
            "learning_objectives": [
                f"Understand core concepts of {topic}",
                f"Apply knowledge of {topic} to real-world examples",
                f"Evaluate and reflect on key ideas within {topic}"
            ],
            "lesson_introduction": f"This lesson introduces students to foundational ideas and real-world relevance of {topic}.",
            "main_topics": [{
                "title": f"{topic} Deep Dive",
                "subtopics": [{
                    "title": f"Core Principles of {topic}",
                    "key_concepts": [
                        {"type": "definition", "content": f"Key terms and concepts in {topic}."},
                        {"type": "example", "content": f"An everyday scenario involving {topic}."}
                    ],
                    "discussion_questions": [{"question": f"Why is {topic} important in today’s world?"}],
                    "hands_on_activities": [{"title": f"Explore {topic}", "description": f"Group activity analyzing a real-world example of {topic}."}],
                    "reflective_questions": [{"question": f"How does {topic} affect you personally?"}],
                    "assessment_ideas": [{"type": "project", "description": f"Create a poster or presentation explaining {topic}."}]
                }]
            }],
            "learning_adaptations": f"Support for learners new to {topic}.",
            "real_world_applications": f"{topic} is used across industries.",
            "ethical_considerations": f"Explore ethical issues related to {topic}."
        })

    @property
    def _llm_type(self) -> str:
        return "mock"

    def invoke(self, input, config=None, **kwargs):
        return AIMessage(content=self._call(str(input)))

    def generate_prompt(self, *args, **kwargs):
        return ChatResult(generations=[[ChatGeneration(message=AIMessage(content=self._call("mock prompt")))]])
    
def get_lesson_plan(topic):
    mock_llm = MockLLM()
    llm_config = LLMConfig(custom_model=mock_llm)
    engine = ContentEngine(llm_config=llm_config)
    return engine.generate_lesson_plan(topic)

