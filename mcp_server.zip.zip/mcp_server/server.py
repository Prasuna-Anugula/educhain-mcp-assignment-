'''# mcp_server/server.py

from flask import Flask, request, jsonify, make_response
from mcp_server.educhain_wrapper import get_lesson_plan

app = Flask(__name__)

@app.route('/generate_lesson_plan', methods=['POST'])
def lesson_plan():
    try:
        data = request.json
        topic = data.get("topic", "Python Basics")
        plan = get_lesson_plan(topic)

        # ✅ Ensure JSON response is clear and structured
        response = make_response(jsonify(plan.model_dump()), 200)
        response.headers["Content-Type"] = "application/json"
        return response

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(port=8000)'''
from flask import Flask, request, jsonify, make_response
from mcp_server.educhain_wrapper import get_lesson_plan

app = Flask(__name__)

@app.route('/generate_lesson_plan', methods=['POST'])
def lesson_plan():
    try:
        data = request.json
        topic = data.get("topic", "Python")
        plan = get_lesson_plan(topic)
        response = make_response(jsonify(plan.model_dump()), 200)
        response.headers["Content-Type"] = "application/json"
        return response
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(port=8000)
