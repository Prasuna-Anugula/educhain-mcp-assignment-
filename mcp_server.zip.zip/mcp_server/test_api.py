import requests

res = requests.post("http://localhost:8000/generate_lesson_plan", json={"topic": "Cybersecurity"})


print("Response from MCP server:")
print(res.json())
